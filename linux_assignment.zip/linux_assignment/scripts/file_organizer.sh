#!/bin/bash

BASE_DIR="$HOME/linux_assignment"
DOCUMENTS_DIR="$BASE_DIR/Documents"
OTHERS_DIR="$BASE_DIR/Others"
IMAGES_DIR="$BASE_DIR/Images"

mkdir -p "$DOCUMENTS_DIR" "$OTHERS_DIR" "$IMAGES_DIR"

doc_count=0
other_count=0

shopt -s nullglob

for file in "$BASE_DIR"/*; do
    if [ -f "$file" ]; then
        filename=$(basename "$file")

        case "$filename" in
            *.txt|*.md|*.pdf)
                mv "$file" "$DOCUMENTS_DIR/"
                echo "Moved $filename to Documents/"
                ((doc_count++))
                ;;
            *.csv|*.conf)
                mv "$file" "$OTHERS_DIR/"
                echo "Moved $filename to Others/"
                ((other_count++))
                ;;
        esac
    fi
done

echo "======================================"
echo "File Organization Summary"
echo "Files moved to Documents: $doc_count"
echo "Files moved to Others: $other_count"
echo "======================================"
