NAME="NORFARIS NAZMI BIN NORAZMAN"
LOG_DIR="$HOME/linux_assignment/logs"
LOG_FILE="$LOG_DIR/system_log_$(date +%Y%m%d).log"

mkdir -p "$LOG_DIR"

{
echo "======================================"
echo "Welcome, $NAME"
echo "System Information Report"
echo "======================================"
echo

echo "Current Date and Time:"
date
echo

echo "Disk Usage:"
df -h
echo

echo "Memory Usage:"
free -h
echo

echo "Top 5 Processes by CPU Usage:"
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 6
echo

echo "Report saved to: $LOG_FILE"
echo "======================================"
} | tee "$LOG_FILE"
