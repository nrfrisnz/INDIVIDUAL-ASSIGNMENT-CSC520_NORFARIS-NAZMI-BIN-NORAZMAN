#!/bin/bash

BASE_DIR="$HOME/linux_assignment"
INPUT_FILE="$BASE_DIR/student_list.txt"
OUTPUT_DIR="$BASE_DIR/student_submissions"
LOG_DIR="$BASE_DIR/logs"
LOG_FILE="$LOG_DIR/folder_creation.log"

processed_count=0
skipped_count=0

declare -A groups_created

# Create logs folder
mkdir -p "$LOG_DIR"

# Check if student_list.txt exists
if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: student_list.txt file not found in $BASE_DIR"
    echo "Please make sure student_list.txt is placed inside ~/linux_assignment/"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: student_list.txt file not found." > "$LOG_FILE"
    exit 1
fi

# Create main student_submissions folder
mkdir -p "$OUTPUT_DIR"

# Start log file
echo "======================================" > "$LOG_FILE"
echo "Folder Creation Log" >> "$LOG_FILE"
echo "Date and Time: $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
echo "======================================" >> "$LOG_FILE"

# Read student_list.txt line by line
while IFS= read -r line || [ -n "$line" ]
do
    # Remove Windows carriage return if the file came from Windows
    line="${line//$'\r'/}"

    # Skip empty lines
    if [ -z "$(echo "$line" | xargs)" ]; then
        ((skipped_count++))
        continue
    fi

    # Skip header line
    if echo "$line" | grep -qi "^No[[:space:]]"; then
        continue
    fi

    # Extract matric number and group number
    matric=$(echo "$line" | awk '{print $2}')
    group_number=$(echo "$line" | awk '{print $NF}')

    # Check for malformed lines
    if [ -z "$matric" ] || [ -z "$group_number" ]; then
        echo "Skipped malformed line: $line"
        echo "Skipped malformed line: $line" >> "$LOG_FILE"
        ((skipped_count++))
        continue
    fi

    # Create group folder name and replace space with underscore
    group_name="Group $group_number"
    group_folder="${group_name// /_}"

    # Create group folder and matric number subfolder
    mkdir -p "$OUTPUT_DIR/$group_folder/$matric"

    # Store group name for summary
    groups_created["$group_folder"]=1

    # Count processed students
    ((processed_count++))

    # Print and log result
    echo "Created folder: $OUTPUT_DIR/$group_folder/$matric"
    echo "Created folder: $OUTPUT_DIR/$group_folder/$matric" >> "$LOG_FILE"

done < "$INPUT_FILE"

# Count groups created
group_count=${#groups_created[@]}

# Create sorted group list
group_list=$(printf "%s\n" "${!groups_created[@]}" | sort -V | awk 'BEGIN{ORS=""}{if(NR>1) printf ", "; printf "%s",$0}')

# Print summary
echo "======================================"
echo "Student Folder Creation Summary"
echo "Total students processed: $processed_count"
echo "Number of groups created: $group_count"
echo "Groups created: $group_list"
echo "Skipped lines: $skipped_count"
echo "======================================"

# Save summary to log file
echo "======================================" >> "$LOG_FILE"
echo "Student Folder Creation Summary" >> "$LOG_FILE"
echo "Total students processed: $processed_count" >> "$LOG_FILE"
echo "Number of groups created: $group_count" >> "$LOG_FILE"
echo "Groups created: $group_list" >> "$LOG_FILE"
echo "Skipped lines: $skipped_count" >> "$LOG_FILE"
echo "======================================" >> "$LOG_FILE"
